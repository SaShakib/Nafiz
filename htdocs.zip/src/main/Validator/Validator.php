<?php

class Validator
{
    private $inputs;
    private $message = null;

    function __construct(array $inputs)
    {
        $this->inputs = $inputs['data'];
        $types = [
            "0" => (new Disk($this->inputs)),
            "1" => (new Book($this->inputs)),
            "2" => (new Furniture($this->inputs))
        ];

        $this->validate($types[$this->inputs['type']]);
    }

    public function validate(Validate $validate)
    {
        !$validate->validateSKU() && $this->message .= 'Invalid SKU or already exists <br>';
        !$validate->validateName() && $this->message .= 'Invalid name <br>';
        $validate->validatePrice() && $this->message .= 'Invalid price <br>';
        $validate->validateType() && $this->message .= 'Invalid type <br>';
        !$validate->validateAttributes() && $this->message .= 'Invalid attributes <br>';

        ($this->message == null) && $this->saveData($validate);
        (!$this->message == null) && response(array('status' => 'danger', 'message' => $this->message));
    }

    public function saveData($validate)
    {
        $validate->save();
        return response(array('status' => 'success', 'message' => 'Product added to the database'));
    }
};
