<?php

class ProductController
{
    public static function getAllProduct()
    {
        return response((new Product)->getAll());
    }

    public static function addProduct(): void 
    {
        $inputs = json_decode(file_get_contents('php://input'), true);

        $validator = new Validator($inputs);
    }

    public static function deleteProduct()
    {
        $inputs = json_decode(file_get_contents('php://input'), true);

        foreach ($inputs['data'] as $value) {
            (new Product)->delete('sku', $value);
        }

        return response(array('status' => 'success', 'message' => 'Deleted count of products: '.count($inputs['data'])));
    }

};