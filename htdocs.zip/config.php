<?php
    define('DBUSER', 'u192896231_nafiz');
    define('DBPASSWORD', 'Nafizbd12!#');
    define('DBHOST', 'localhost');
    define('DBNAME', 'u192896231_nafiz');

    // define('DBUSER', 'root');
    // define('DBPASSWORD', '');
    // define('DBHOST', 'localhost');
    // define('DBNAME', 'scandiweb');